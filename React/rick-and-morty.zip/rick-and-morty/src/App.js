import Chars from "./pages/chars";

function App() {
  return <Chars />;
}

export default App;
